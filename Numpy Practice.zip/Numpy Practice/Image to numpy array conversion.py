import pandas as pd
from PIL import Image
from matplotlib.image import imread

img_path = r"C:\Users\bharg\Documents\Sunny\Images\panda.png"


panda = imread(r"C:\Users\bharg\Documents\Sunny\Images\panda.png")
print(panda)